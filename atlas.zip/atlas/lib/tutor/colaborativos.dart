import 'dart:io';
import 'dart:typed_data';

import 'package:atlas/tutor/individuales';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart'; // Importar path_provider
import 'package:open_file/open_file.dart'; // Opcional, para abrir el archivo después de guardar

// Solo importar html para plataformas web
import 'dart:html' as html if (dart.library.html) 'package:html/html.dart';
import 'package:atlas/inicio.dart';
import 'package:atlas/main.dart';
import 'package:atlas/respaldos/descargas.dart';
import 'package:atlas/tutor/actualizar.dart';
import 'package:atlas/tutorados/poblacion.dart';
import 'package:atlas/tutor/alta.dart';
import 'package:atlas/tutor/consultar.dart';
import 'package:atlas/tutorados/nuevo_ingreso.dart';


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Colaborativo',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 34, 255, 244)),
      ),
      home: ColaborativoPage(),
    );
  }
}

class ColaborativoPage extends StatefulWidget {
  @override
  _ColaborativoPageState createState() => _ColaborativoPageState();
}

class _ColaborativoPageState extends State<ColaborativoPage> {
  Color _inicioColor = Colors.white;
  Color _salirColor = Colors.white;
  String _mensajeExito = '';
  List<List<String>> excelData = [];
  List<List<String>> filteredData = []; // Para los datos filtrados
  String? _filePath; // Ruta del archivo Excel
  TextEditingController _searchController = TextEditingController(); // Controlador de búsqueda

  @override
  void initState() {
    super.initState();
    _loadPredefinedExcel();
    _searchController.addListener(_filterData); // Agregar listener para actualizar la búsqueda
  }

  // Filtrar datos de acuerdo al texto ingresado en la búsqueda
  void _filterData() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      filteredData = excelData
          .where((row) => row.any((cell) => cell.toLowerCase().contains(query)))
          .toList();
    });
  }

  // Cargar el archivo Excel desde la ubicación adecuada
  void _loadPredefinedExcel() async {
    try {
      Uint8List bytes;

      if (kIsWeb) {
        // Para web, cargar desde assets (nota: no se puede sobrescribir en web)
        final data = await rootBundle.load('assets/images/tutores.xlsx');
        bytes = data.buffer.asUint8List();
      } else {
        // Para escritorio, obtener la ruta de documentos
        final directory = await getApplicationDocumentsDirectory();
        final path = '${directory.path}/tutores.xlsx';
        final file = File(path);

        if (!file.existsSync()) {
          throw Exception('El archivo tutores.xlsx no existe en: $path');
        }

        bytes = file.readAsBytesSync();
        _filePath = file.path; // Guardar la ruta para sobrescribir
      }

      final excel = Excel.decodeBytes(bytes);

      List<List<String>> tempData = [];
      for (var table in excel.tables.keys) {
        var sheet = excel.tables[table]!;

        for (var row in sheet.rows) {
          List<String> rowData = [];
          for (var cell in row) {
            rowData.add(cell?.value?.toString() ?? '');
          }
          tempData.add(rowData);
        }
        break; // Solo la primera hoja
      }

      setState(() {
        excelData = tempData;
        filteredData = tempData; // Inicialmente mostrar todos los datos
        _mensajeExito = 'Archivo cargado exitosamente.';
      });
    } catch (e) {
      print('Error al cargar el archivo Excel: $e');
      setState(() {
        _mensajeExito = 'Error al cargar el archivo.';
      });
    }
  }

  // Guardar los cambios sobrescribiendo el archivo existente
  void _saveExcel() async {
    try {
      if (kIsWeb) {
        // Para web: no es posible sobrescribir directamente, se debe descargar el archivo
        var excel = Excel.createExcel();
        Sheet sheet = excel['Sheet1'];

        for (var row in excelData) {
          sheet.appendRow(row);
        }

        final bytes = excel.encode();
        if (bytes == null) {
          throw Exception('No se pudo codificar el archivo Excel.');
        }

        // Bloque que usa html solo en plataformas web
        final blob = html.Blob([bytes]);
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..target = 'blank'
          ..download = 'tutores.xlsx';
        anchor.click();
        html.Url.revokeObjectUrl(url);

        setState(() {
          _mensajeExito = 'Archivo actualizado y descargado correctamente.';
        });
      } else {
        // Para escritorio o móvil: Sobrescribir el archivo
        if (_filePath == null) {
          throw Exception('Ruta del archivo no definida.');
        }

        var excel = Excel.createExcel();
        Sheet sheet = excel['Sheet1'];

        for (var row in excelData) {
          sheet.appendRow(row);
        }

        final encoded = excel.encode();
        if (encoded == null) {
          throw Exception('No se pudo codificar el archivo Excel.');
        }

        final file = File(_filePath!);
        await file.writeAsBytes(encoded, flush: true); // Sobrescribir el archivo existente

        setState(() {
          _mensajeExito = 'Archivo sobrescrito exitosamente en: $_filePath';
        });
      }
    } catch (e) {
      print('Error al guardar el archivo Excel: $e');
      setState(() {
        _mensajeExito = 'Error al guardar el archivo.';
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  '    A T L A S    | ',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                MouseRegion(
                  onEnter: (_) => setState(() => _inicioColor = const Color.fromARGB(255, 241, 218, 5)),
                  onExit: (_) => setState(() => _inicioColor = Colors.white),
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => InicioPage()),
                      );
                    },
                    child: Text(
                      'Inicio',
                      style: TextStyle(
                        color: _inicioColor,
                        fontSize: 15,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ),
                VerticalDivider(color: Colors.white),
                // Popup para "Tutores"
                MouseRegion(
                  onEnter: (_) => setState(() => _inicioColor = const Color.fromARGB(255, 241, 218, 5)),
                  onExit: (_) => setState(() => _inicioColor = Colors.white),
                  child: PopupMenuButton<String>(
                    onSelected: (String result) {
                      switch (result) {
                        case 'individual':
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => IndividualPage()),
                          );
                          break;
                        case 'actualizas':
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ActualizarPage()),
                          );
                          break;
                        case 'dar_de_alta':
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => AltaPage()),
                          );
                          break;
                        case 'eliminar':
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ColaborativoPage()),
                          );
                          break;
                        case 'consultas':
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ConsultaPage()),
                          );
                          break;
                        default:
                          print(result);
                      }
                    },
                    itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                      PopupMenuItem<String>(
                        value: 'dar_de_alta',
                        child: Text('Dar de Alta'),
                      ),
                      PopupMenuItem<String>(
                        value: 'eliminar',
                        child: Text('Activar Colaborativos'),
                      ),
                      PopupMenuItem<String>(
                        value: 'individual',
                        child: Text('Activar Individuales'),
                      ),
                      PopupMenuItem<String>(
                        value: 'actualizas',
                        child: Text('Actualizar Datos'),
                      ),
                      PopupMenuItem<String>(
                        value: 'consultas',
                        child: Text('Consultar'),
                      ),
                    ],
                    child: Text(
                      'Tutores',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ),
                VerticalDivider(color: Colors.white),
                // Popup para "Tutorados"
                PopupMenuButton<String>(
                  onSelected: (String result) {
                    switch (result) {
                      case 'poblacion':
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => PoblacionPage()),
                        );
                        break;
                      case 'nuevo_ingreso':
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => NuevoIngresoPage()),
                        );
                        break;
                      default:
                        print(result);
                    }
                  },
                  itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                    PopupMenuItem<String>(
                      value: 'poblacion',
                      child: Text('Población'),
                    ),
                    PopupMenuItem<String>(
                      value: 'nuevo_ingreso',
                      child: Text('Nuevo Ingreso'),
                    ),
                  ],
                  child: Text(
                    'Tutorados',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                VerticalDivider(color: Colors.white),
                // Popup para "Respaldo"
                PopupMenuButton<String>(
                  onSelected: (String result) {
                    if (result == 'descargar') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => DescargasPage()),
                      );
                    } else {
                      print(result);
                    }
                  },
                  itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                    PopupMenuItem<String>(
                      value: 'descargar',
                      child: Text('Descargar'),
                    ),
                  ],
                  child: Text(
                    'Respaldo',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
              ],
            ),
            MouseRegion(
              onEnter: (_) => setState(() => _salirColor = const Color.fromARGB(255, 241, 218, 5)),
              onExit: (_) => setState(() => _salirColor = Colors.white),
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginPage()), // Redirige a la nueva página
                  );
                },
                child: Text(
                  'Salir',
                  style: TextStyle(
                    color: _salirColor,
                    fontSize: 15,
                    fontWeight: FontWeight.normal,
                  ),
                ),
              ),
            ),
          ],
        ),
        backgroundColor: const Color.fromARGB(255, 15, 105, 60),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),
            Text(
              'Tutores colaborativos',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            // Barra de búsqueda
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  labelText: 'Buscar tutor por nombre',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.search),
                ),
              ),
            ),
            SizedBox(height: 20),
            if (filteredData.isNotEmpty) ...[
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: filteredData[0]
                      .map((header) => DataColumn(label: Text(header)))
                      .toList(),
                  rows: filteredData.skip(1).map((row) {
                    return DataRow(
                      cells: row.map((cell) {
                        if (cell == 'TRUE' || cell == 'FALSE') {
                          return DataCell(
                            Checkbox(
                              value: cell == 'TRUE',
                              onChanged: (bool? newValue) {
                                setState(() {
                                  int rowIndex = filteredData.indexOf(row);
                                  int colIndex = row.indexOf(cell);
                                  filteredData[rowIndex][colIndex] =
                                      newValue! ? 'TRUE' : 'FALSE';
                                });
                              },
                            ),
                          );
                        } else {
                          return DataCell(Text(cell));
                        }
                      }).toList(),
                    );
                  }).toList(),
                ),
              ),
            ] else
              Center(
                child: Text(
                  _mensajeExito.isNotEmpty ? _mensajeExito : 'Cargando...',
                  style: TextStyle(color: Colors.black),
                ),
              ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _saveExcel,
              child: Text('Guardar Cambios'),
            ),
            SizedBox(height: 30),
            // Espacio antes de la nueva sección
            Container(
              color: const Color.fromARGB(255, 15, 105, 60),
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 30),
              child: Column(
                children: [
                  Text(
                    '"2024, Conmemoración de los 195 Años de la Fundación del Instituto Literario del Estado de México"',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Vínculos de interés
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'VÍNCULOS DE INTERÉS',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 10),
                          InkWell(
                            onTap: () {
                              // Acciones al pulsar
                            },
                            child: Text(
                              'SiTAA',
                              style: TextStyle(
                                  color: Colors.white,
                                  decoration: TextDecoration.underline),
                            ),
                          ),
                          SizedBox(height: 5),
                          InkWell(
                            onTap: () {
                              // Acciones al pulsar
                            },
                            child: Text(
                              'UAEMéx',
                              style: TextStyle(
                                  color: Colors.white,
                                  decoration: TextDecoration.underline),
                            ),
                          ),
                          SizedBox(height: 5),
                          InkWell(
                            onTap: () {
                              // Acciones al pulsar
                            },
                            child: Text(
                              'Delfos',
                              style: TextStyle(
                                  color: Colors.white,
                                  decoration: TextDecoration.underline),
                            ),
                          ),
                        ],
                      ),
                      // Coordinación de Tutoría Académica
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'COORDINACIÓN DE TUTORÍA ACADÉMICA',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(Icons.email,
                                  color: Colors.white, size: 20),
                              SizedBox(width: 5),
                              Text(
                                'tutoria_fi@uaemex.mx',
                                style: TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.phone,
                                  color: Colors.white, size: 20),
                              SizedBox(width: 5),
                              Text(
                                '(722) 895 9749',
                                style: TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                        ],
                      ),
                      // Datos de contacto
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'DATOS DE CONTACTO',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(Icons.location_on,
                                  color: Colors.white, size: 20),
                              SizedBox(width: 5),
                              Text(
                                'Facultad de Ingeniería UAEM',
                                style: TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Cerro de Coatepec S/N, Ciudad Universitaria C.P. 50100.\nToluca, Estado de México',
                            style: TextStyle(color: Colors.white),
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.phone,
                                  color: Colors.white, size: 20),
                              SizedBox(width: 5),
                              Text(
                                '(722) 214 08 55 y 214 07 95',
                                style: TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20), // Espacio al final
          ],
        ),
      ),
    );
  }
}
