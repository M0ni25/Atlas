import 'package:flutter/material.dart';
import 'package:atlas/inicio.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Atlas Login',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 34, 255, 244)),
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  Color _inicioColor = Colors.white;
  Color _salirColor = Colors.white;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
  title: Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween, // Para espaciar el contenido
    children: [
      Row(
        children: [
          Text(
            '    A T L A S    | ',
            style: TextStyle(
              color: Colors.white,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
      MouseRegion(
        onEnter: (_) => setState(() => _salirColor = const Color.fromARGB(255, 241, 218, 5)),
        onExit: (_) => setState(() => _salirColor = Colors.white),
        child: TextButton(
          onPressed: () {
                
              },
          child: Text(
            'Salir',
            style: TextStyle(
              color: _salirColor,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
      ),
    ],
  ),
  backgroundColor: const Color.fromARGB(255, 15, 105, 60),
),

      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              Image.asset(
                'assets/images/atlas_login.png',
                height: 300, // Ajusta el tamaño si es necesario
              ),
              SizedBox(height: 20),
              Text(
                'Usuario:',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              SizedBox(
                width: 300,
                height: 50,
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'correo@uaemex.mx',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Text(
                'Contraseña:',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              SizedBox(
                width: 300,
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Ingresa tu contraseña',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InicioPage()), // Redirige a la nueva página
                );
              },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 186, 153, 21),
                ),
                child: Text(
                  'Ingresar',
                  style: TextStyle(
                    color: Colors.white, // Cambia el color del texto del botón
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
